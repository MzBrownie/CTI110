# File Display
# 5 July 2017
# CTI-110 M6T1 - File Display
# Patrice Browne
#

def main():
    myFile = open("numbers.txt","r")
    
    line = myFile.readline()
    line = line.rstrip()
    while line != '':
        print(line)
        line = myFile.readline()
        line = line.rstrip()

    myFile.close()

main()
