# M6a - special topics
# some turtle graphics using recursion

import turtle             # Allows us to use turtles
import m6a_fractal2

def main():
    wn = turtle.Screen()      # Creates a playground for turtles
    t = turtle.Turtle()    # Create a turtle, assign to alex
    # begin drawing
    # first back up to give us some room
    setup(t)
    
    m6a_fractal2.koch(t, 0, 100)
    space(t)
    
    m6a_fractal2.koch(t, 1, 100)
    space(t)
    
    m6a_fractal2.koch(t, 2, 100)
    space(t)
    
    m6a_fractal2.koch(t, 3, 100)
    space(t)
    m6a_fractal2.koch(t, 4, 100)
    
    # end drawing
    wn.mainloop()             # Wait for user to close window


def setup(t):
    # give us some room to work
    t.penup()
    t.back(300)
    t.pendown()

def space(t):
    # a little bit of room
    t.penup()
    t.forward(20)
    t.pendown()

main()
