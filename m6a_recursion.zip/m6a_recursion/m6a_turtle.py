# M6a - special topics
# some turtle graphics using recursion

import turtle             # Allows us to use turtles
import m6a_fractal1

def main():
    wn = turtle.Screen()      # Creates a playground for turtles
    t = turtle.Turtle()    # Create a turtle, assign to alex
    # begin drawing
    # first back up to give us some room
    setup(t)
    
    m6a_fractal1.koch_0(t, 100)
    space(t)
    
    m6a_fractal1.koch_1(t, 100)
    space(t)
    
    m6a_fractal1.koch_2(t, 100)
    space(t)
    
    m6a_fractal1.koch_3(t, 100)
    
    # end drawing
    wn.mainloop()             # Wait for user to close window


def setup(t):
    # give us some room to work
    t.penup()
    t.back(300)
    t.pendown()

def space(t):
    # a little bit of room
    t.penup()
    t.forward(20)
    t.pendown()

main()
