# This program writes a series of random
# numbers to a file
# Date
# CTI-110 M6HW1 - Random Number File Writer
# Your Name
#

import random
file = open('M6HW1_RandomNumbers.txt', 'w')
#def main():
for count in range(6):
    number = (random.randint(1, 69))
    file.write(str(number) + '\n')
file.close()

print("Action Complete.")

    


