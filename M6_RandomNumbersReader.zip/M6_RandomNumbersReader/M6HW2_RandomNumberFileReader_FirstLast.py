# this program reads numbers
# from an existing file, adds the total
# and gives the amount of numbers read form the file
# July 16, 2017
# CTI-110 M6HW2 - Random Number File Reader
# Patrice Browne
#

def main():
    file = open('M6HW1_RandomNumbers.txt', 'r')

    firstNumber = int(file.read.readline())
    secondNumber = int(file.read.readline())
    thirdNumber = int(file.read.readline())
    fourthNumber = int(file.read.readline())
    fifthNumber = int(file.read.readline())
    sixthNumber = int(file.read.readline())

    file.close()
    total = firstNumber + secondNumber + thirdNumber + fouthNumber + fifthNumber + sixthNumber

    print("Numbers:", firstNumber, secondNumber, thirdNumber, fourthNumber, fifthNumber, sixthNumber)
    print("Total of Numbers given:", total)

main()
