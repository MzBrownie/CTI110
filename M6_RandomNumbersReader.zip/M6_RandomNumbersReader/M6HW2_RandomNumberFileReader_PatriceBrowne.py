# this program reads numbers
# from an existing file, adds the total
# and gives the amount of numbers read form the file
# July 16, 2017
# CTI-110 M6HW2 - Random Number File Reader
# Patrice Browne
#

def main():
    file = open('M6HW1_RandomNumbers.txt', 'r')

    firstNumber = int(file.readline())
    secondNumber = int(file.readline())
    thirdNumber = int(file.readline())
    fourthNumber = int(file.readline())
    fifthNumber = int(file.readline())
    sixthNumber = int(file.readline())

    file.close()
    
    total = firstNumber + secondNumber + thirdNumber + fourthNumber + fifthNumber + sixthNumber

    print("Numbers given:", firstNumber, secondNumber, thirdNumber, fourthNumber, fifthNumber, sixthNumber)
    print("Total of Numbers given:", total)

main()
