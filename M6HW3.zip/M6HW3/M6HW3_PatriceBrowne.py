# this program is for exection handeling
# July 16, 2017
# M6HW3 - Exception handeling
# Patrice Browne

def main():
    try:
        
        file = open("numbers.txt","r")

        num1 = int(file.readline())
        num2 = int(file.readline())
        num3 = int(file.readline())
        num4 = int(file.readline())
        num5 = int(file.readline())

        file.close()

        average = (num1 + num2 + num3 + num4 + num5)/5

        print("Numbers given:", num1, num2, num3, num4, num5)
        print("Average of numbers given:", average)

    except ValueError:
        print("ERROR: Must enter five numbers only.")
    except FileNotFoundError:
        print("ERROR: File does not exist.")
        print("Check file location or file spelling.")


main()

