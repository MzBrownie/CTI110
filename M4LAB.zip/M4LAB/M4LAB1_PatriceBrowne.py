import turtle          
win = turtle.Screen()  
t = turtle.Turtle()

# add some display options
t.pensize(8)            # increase pensize (takes integer)
t.pencolor("blue")     # set pencolor (takes string)
t.shape("turtle")

#commands from here to the last line can be replaced
# pentagon, sides are 360 / 5 = 120 degrees
 

# draw the triangle
for i in (1,2,3):
    t.forward(100)
    t.left(120)
t.penup()

t.left(180)
t.forward (150)
t.pencolor("purple")
t.pendown()

for i in (1,2,3,4):
    t.forward(100)
    t.left(90)

# draw square
 


# end commands
win.mainloop()             # Wait for user to close window
