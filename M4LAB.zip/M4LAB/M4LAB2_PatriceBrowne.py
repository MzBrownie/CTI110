import turtle          
win = turtle.Screen()  
t = turtle.Turtle()


t.pensize(8)            
t.pencolor("blue")     
t.shape("turtle")


side_length = 180;
t.forward(side_length)          
t.left(90)            
t.forward(side_length)
t.left(90)
t.forward(side_length)
t.left(90)
t.forward(side_length)
t.forward(side_length)
t.left(90)
t.penup()
t.forward(side_length*2)
t.pendown()
t.pencolor("red")
t.forward(side_length)
t.left(90)
t.forward(side_length)
t.left(90)
t.forward(side_length)
t.penup()
t.right(180)
t.forward(side_length)
t.left(90)
t.pendown()
t.forward(side_length)
t.left(90)
t.forward(side_length)
t.left(90)
t.forward(side_length*2)


win.mainloop()
